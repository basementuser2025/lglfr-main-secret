// 为Child添加异步等待方法的扩展trait
trait AsyncWait {
    async fn async_wait(&mut self) -> std::io::Result<std::process::ExitStatus>;
}

impl AsyncWait for Child {
    async fn async_wait(&mut self) -> std::io::Result<std::process::ExitStatus> {
        loop {
            match self.try_wait() {
                Ok(Some(status)) => return Ok(status),
                Ok(None) => {
                    // 进程仍在运行，短暂休眠后继续检查
                    tokio::time::sleep(Duration::from_millis(100)).await;
                    continue;
                }
                Err(e) => return Err(e),
            }
        }
    }
}

use std::process::{Command, Child};
use std::path::PathBuf;
use std::fs;
use std::net::UdpSocket;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Duration;
use anyhow::{Result, Context, anyhow};
use tempfile::TempDir;
use log::{info, error, warn};
use tokio::time::sleep;
use ctrlc;

// 包含压缩的服务资源
static EMBEDDED_SERVER: &[u8] = include_bytes!("../resources/lglfr_x86_64-linux_vswsm.zip");

// 定义服务配置
const UDP_PORT: u16 = 49920;
const WEB_PORT: u16 = 9920;
const UDP_BUFFER_SIZE: usize = 1024;

// UDP消息处理器
async fn handle_udp_message(socket: &UdpSocket, buf: &[u8], size: usize) -> Result<()> {
    let message = String::from_utf8_lossy(&buf[..size]);
    info!("收到UDP消息: {}", message);
    
    // 这里可以根据需要处理UDP消息
    let response = format!("已收到消息: {}", message);
    socket.send_to(response.as_bytes(), "127.0.0.1:49920")?;
    
    Ok(())
}

struct ServerWrapper {
    temp_dir: TempDir,
    server_path: PathBuf,
    running: Arc<AtomicBool>,
}

impl ServerWrapper {
    pub fn new() -> Result<Self> {
        // 创建临时目录
        let temp_dir = TempDir::new().context("创建临时目录失败")?;
        let temp_path = temp_dir.path();

        // 将内嵌的zip文件写入临时文件
        let zip_path = temp_path.join("server.zip");
        fs::write(&zip_path, EMBEDDED_SERVER).context("Failed to write zip file")?;

        // 解压文件
        let mut archive = zip::ZipArchive::new(fs::File::open(&zip_path)?)?;
        
        // 创建目标目录
        let extract_path = temp_path.join("lglfr_x86_64-linux_vswsm");
        fs::create_dir_all(&extract_path)?;
        
        // 解压所有文件
        for i in 0..archive.len() {
            let mut file = archive.by_index(i)?;
            let outpath = match file.enclosed_name() {
                Some(path) => extract_path.join(path),
                None => continue,
            };

            if file.name().ends_with('/') {
                fs::create_dir_all(&outpath)?;
            } else {
                if let Some(p) = outpath.parent() {
                    if !p.exists() {
                        fs::create_dir_all(p)?;
                    }
                }
                let mut outfile = fs::File::create(&outpath)?;
                std::io::copy(&mut file, &mut outfile)?;
            }
        }

        // 构建server.exe路径
        let server_path = extract_path.join("server.exe");
        
        // 确保server有执行权限
        Command::new("icacls")
            .arg("/grant Administrators:F")
            .arg(&server_path)
            .output()
            .context("Failed to set executable permission")?;

        let running = Arc::new(AtomicBool::new(true));
        
        Ok(Self {
            temp_dir,
            server_path,
            running,
        })
    }

    pub async fn run(&self) -> Result<()> {
        // 设置Ctrl+C处理
        let running = self.running.clone();
        ctrlc::set_handler(move || {
            info!("收到终止信号，正在优雅关闭...");
            running.store(false, Ordering::SeqCst);
        })?;

        // 启动UDP监听器
        let udp_socket = UdpSocket::bind(format!("127.0.0.1:{}", UDP_PORT))
            .context("UDP端口绑定失败")?;
        udp_socket.set_nonblocking(true)?;
        info!("UDP监听器已启动在端口 {}", UDP_PORT);

        // 启动server进程
        let mut server_process = Command::new(&self.server_path)
            .current_dir(self.server_path.parent().unwrap())
            .spawn()
            .context("启动服务进程失败")?;

        info!("服务已成功启动在 http://localhost:{}", WEB_PORT);

        // UDP处理
        let socket_clone = udp_socket.try_clone()?;
        tokio::spawn(async move {
            let mut buf = [0u8; UDP_BUFFER_SIZE];
            while let Ok((size, _)) = socket_clone.recv_from(&mut buf) {
                if let Err(e) = handle_udp_message(&socket_clone, &buf, size).await {
                    error!("处理UDP消息时出错: {}", e);
                }
            }
        });

        // 主循环
        while self.running.load(Ordering::SeqCst) {
            tokio::select! {
                // 检查服务进程是否已经退出
                status = server_process.async_wait() => {
                    match status {
                        Ok(status) => {
                            error!("服务进程已退出，状态码: {}", status);
                            break;
                        },
                        Err(e) => {
                            error!("等待服务进程时出错: {}", e);
                            break;
                        }
                    }
                },
                _ = sleep(Duration::from_secs(1)) => {
                    // 定期检查运行状态
                    continue;
                }
            }
        }

        // 优雅关闭
        info!("正在关闭服务...");
        if let Err(e) = server_process.kill() {
            warn!("关闭服务进程时出错: {}", e);
        }

        // 等待进程完全退出
        match server_process.wait() {
            Ok(status) => info!("服务进程已退出，状态码: {}", status),
            Err(e) => error!("等待服务进程退出时出错: {}", e),
        }

        Ok(())
    }
    
}

#[tokio::main]
async fn main() -> Result<()> {
    // 初始化日志，设置默认日志级别为info
    if std::env::var("RUST_LOG").is_err() {
        std::env::set_var("RUST_LOG", "info");
    }
    env_logger::try_init().map_err(|e| anyhow!("初始化日志失败: {}", e))?;

    info!("正在启动服务包装器...");
    info!("Web服务将在端口 {} 上运行", WEB_PORT);
    info!("UDP监听器将在端口 {} 上运行", UDP_PORT);

    // 只检查UDP端口是否已被占用
    if let Ok(_) = UdpSocket::bind(format!("127.0.0.1:{}", UDP_PORT)) {
        // UDP端口可用
    } else {
        return Err(anyhow!("UDP端口 {} 已被占用", UDP_PORT));
    }

    // 创建并运行服务包装器
    let wrapper = ServerWrapper::new()?;
    
    info!("初始化完成，开始运行服务...");
    info!("按 Ctrl+C 可以优雅关闭服务");
    
    let result = wrapper.run().await;
    
    // 清理临时目录
    info!("正在清理临时文件: {:?}", wrapper.temp_dir.path());
    
    if let Err(e) = result {
        error!("服务运行时出错: {}", e);
        return Err(e);
    }

    info!("服务已完全关闭");
    Ok(())
}
