use warp::Filter;
use serde::{Deserialize, Serialize};
use base64::{Engine as _, engine::general_purpose};

#[derive(Serialize, Deserialize)]
struct ConvertRequest {
    file_data: String, // base64 encoded file data
    target_format: String, // "image", "audio", or "video"
    image_format: Option<String>, // "png", "bmp", "jpeg" (only for image target)
}

#[derive(Serialize)]
struct ConvertResponse {
    success: bool,
    message: String, // additional information
    file_data: String, // base64 encoded file data to be processed on frontend
    target_format: String,
    image_format: Option<String>,
}

#[derive(Serialize, Deserialize)]
struct ReverseConvertRequest {
    media_data: String, // base64 encoded media data
    media_type: String, // mime type
}

#[derive(Serialize)]
struct ReverseConvertResponse {
    success: bool,
    file_data: String, // base64 encoded file data
    message: String, // additional information
}

const INDEX_HTML: &str = r#"<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VisiWASM - 文件到媒体转换器</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>VisiWASM</h1>
            <p class="subtitle">文件到媒体无损转换器</p>
        </header>
        
        <main>
            <div class="card">
                <h2 class="card-title">文件转换</h2>
                <p>将任意文件无损转换为图像或音频格式，避免传统Base64编码的数据膨胀问题。</p>
                
                <div class="upload-area" id="uploadArea">
                    <div class="upload-icon">📁</div>
                    <p>拖拽文件到此处或点击选择文件</p>
                    <button class="btn btn-primary" id="selectFileBtn">选择文件</button>
                    <input type="file" id="fileInput" class="file-input">
                </div>
                
                <div class="format-selector">
                    <label for="targetFormat">目标格式:</label>
                    <select id="targetFormat">
                        <option value="image">图像</option>
                        <option value="audio">音频 (WAV)</option>
                        <option value="video">视频 (计划中)</option>
                    </select>
                </div>
                
                <div class="image-format-selector" id="imageFormatSelector">
                    <label for="imageFormat">图像格式:</label>
                    <select id="imageFormat">
                        <option value="png">PNG</option>
                        <option value="bmp">BMP</option>
                        <option value="jpeg">JPEG</option>
                    </select>
                </div>
                
                <div class="controls">
                    <button class="btn btn-primary" id="convertBtn" disabled>转换文件</button>
                </div>
                
                <div class="progress-container" id="progressContainer">
                    <div class="progress-bar" id="progressBar"></div>
                </div>
                
                <div class="status" id="status"></div>
                
                <div class="loading" id="loading">
                    <div class="spinner"></div>
                    <p>正在处理文件...</p>
                </div>
                
                <div class="preview-container">
                    <h3>原始文件预览</h3>
                    <div id="filePreview"></div>
                    
                    <h3>转换后媒体预览</h3>
                    <img id="imagePreview" alt="图像预览">
                    <audio id="audioPlayer" controls></audio>
                    <video id="videoPlayer" controls></video>
                </div>
                
                <div class="download-section" id="downloadSection">
                    <button class="btn btn-success" id="downloadBtn">下载转换后的文件</button>
                </div>
            </div>
            
            <div class="card">
                <h2 class="card-title">媒体还原</h2>
                <p>将转换后的媒体文件还原为原始文件。</p>
                
                <div class="upload-area" id="restoreUploadArea">
                    <div class="upload-icon">📁</div>
                    <p>拖拽媒体文件到此处或点击选择文件</p>
                    <button class="btn btn-primary" id="selectRestoreFileBtn">选择媒体文件</button>
                    <input type="file" id="restoreFileInput" class="file-input">
                </div>
                
                <div class="format-selector">
                    <label for="restoreMediaType">媒体类型:</label>
                    <select id="restoreMediaType">
                        <option value="image">图像</option>
                        <option value="audio">音频 (WAV)</option>
                    </select>
                </div>
                
                <div class="controls">
                    <button class="btn btn-warning" id="restoreBtn" disabled>还原文件</button>
                </div>
                
                <div class="progress-container" id="restoreProgressContainer">
                    <div class="progress-bar" id="restoreProgressBar"></div>
                </div>
                
                <div class="status" id="restoreStatus"></div>
                
                <div class="loading" id="restoreLoading">
                    <div class="spinner"></div>
                    <p>正在还原文件...</p>
                </div>
                
                <div class="download-section" id="restoreDownloadSection">
                    <button class="btn btn-success" id="restoreDownloadBtn">下载还原的文件</button>
                </div>
            </div>
            
            <div class="card">
                <h2 class="card-title">如何工作</h2>
                <p>VisiWASM 使用创新的方法将文件数据直接映射到媒体格式：</p>
                <ul>
                    <li><strong>无数据膨胀</strong> - 相比 Base64 编码，避免了 33% 的数据膨胀</li>
                    <li><strong>双向转换</strong> - 支持文件到媒体和媒体到文件的双向转换</li>
                    <li><strong>跨平台兼容</strong> - 生成的图像和音频文件在所有设备上都有良好支持</li>
                    <li><strong>无损转换</strong> - 使用 PNG、BMP、JPEG 和 WAV 格式确保数据完整性</li>
                    <li><strong>多种格式支持</strong> - 支持多种图像和音频格式</li>
                </ul>
            </div>
        </main>
        
        <footer>
            <p>VisiWASM - 文件到媒体转换器 | 使用 Rust + WebAssembly 构建</p>
        </footer>
    </div>

    <script type="module">
        import init, { MediaConverter } from '/pkg/visi_wasm_lib.js';
        
        // 全局变量
        let selectedFile = null;
        let convertedMediaData = null;
        let convertedMediaType = null;
        let filePreview = null;
        let mediaConverter = null;
        let restoreSelectedFile = null;
        let restoredFileData = null;
        
        // DOM 元素 - 转换部分
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('fileInput');
        const selectFileBtn = document.getElementById('selectFileBtn');
        const convertBtn = document.getElementById('convertBtn');
        const targetFormat = document.getElementById('targetFormat');
        const imageFormatSelector = document.getElementById('imageFormatSelector');
        const imageFormat = document.getElementById('imageFormat');
        const imagePreview = document.getElementById('imagePreview');
        const audioPlayer = document.getElementById('audioPlayer');
        const videoPlayer = document.getElementById('videoPlayer');
        const downloadBtn = document.getElementById('downloadBtn');
        const downloadSection = document.getElementById('downloadSection');
        const statusEl = document.getElementById('status');
        const loadingEl = document.getElementById('loading');
        const progressContainer = document.getElementById('progressContainer');
        const progressBar = document.getElementById('progressBar');
        const filePreviewEl = document.getElementById('filePreview');
        
        // DOM 元素 - 还原部分
        const restoreUploadArea = document.getElementById('restoreUploadArea');
        const restoreFileInput = document.getElementById('restoreFileInput');
        const selectRestoreFileBtn = document.getElementById('selectRestoreFileBtn');
        const restoreBtn = document.getElementById('restoreBtn');
        const restoreMediaType = document.getElementById('restoreMediaType');
        const restoreDownloadSection = document.getElementById('restoreDownloadSection');
        const restoreDownloadBtn = document.getElementById('restoreDownloadBtn');
        const restoreStatusEl = document.getElementById('restoreStatus');
        const restoreLoadingEl = document.getElementById('restoreLoading');
        const restoreProgressContainer = document.getElementById('restoreProgressContainer');
        const restoreProgressBar = document.getElementById('restoreProgressBar');
        
        // 初始化WASM模块
        async function initWasm() {
            try {
                showStatus('正在加载WASM模块...', 'info');
                await init();
                mediaConverter = new MediaConverter();
                showStatus('WASM模块加载成功', 'success');
                console.log('WASM module loaded successfully');
            } catch (error) {
                console.error('Failed to load WASM module:', error);
                showStatus('WASM模块加载失败: ' + error.message, 'error');
            }
        }
        
        // 页面加载时初始化WASM
        document.addEventListener('DOMContentLoaded', initWasm);
        
        // 事件监听器 - 转换部分
        selectFileBtn.addEventListener('click', () => {
            fileInput.click();
        });
        
        fileInput.addEventListener('change', (event) => {
            if (event.target.files.length > 0) {
                selectedFile = event.target.files[0];
                handleFileSelect(selectedFile);
            }
        });
        
        uploadArea.addEventListener('dragover', (event) => {
            event.preventDefault();
            uploadArea.classList.add('dragover');
        });
        
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });
        
        uploadArea.addEventListener('drop', (event) => {
            event.preventDefault();
            uploadArea.classList.remove('dragover');
            
            if (event.dataTransfer.files.length > 0) {
                selectedFile = event.dataTransfer.files[0];
                handleFileSelect(selectedFile);
            }
        });
        
        targetFormat.addEventListener('change', () => {
            if (targetFormat.value === 'image') {
                imageFormatSelector.style.display = 'block';
            } else {
                imageFormatSelector.style.display = 'none';
            }
        });
        
        convertBtn.addEventListener('click', convertFile);
        downloadBtn.addEventListener('click', downloadConvertedMedia);
        
        // 事件监听器 - 还原部分
        selectRestoreFileBtn.addEventListener('click', () => {
            restoreFileInput.click();
        });
        
        restoreFileInput.addEventListener('change', (event) => {
            if (event.target.files.length > 0) {
                restoreSelectedFile = event.target.files[0];
                handleRestoreFileSelect(restoreSelectedFile);
            }
        });
        
        restoreUploadArea.addEventListener('dragover', (event) => {
            event.preventDefault();
            restoreUploadArea.classList.add('dragover');
        });
        
        restoreUploadArea.addEventListener('dragleave', () => {
            restoreUploadArea.classList.remove('dragover');
        });
        
        restoreUploadArea.addEventListener('drop', (event) => {
            event.preventDefault();
            restoreUploadArea.classList.remove('dragover');
            
            if (event.dataTransfer.files.length > 0) {
                restoreSelectedFile = event.dataTransfer.files[0];
                handleRestoreFileSelect(restoreSelectedFile);
            }
        });
        
        restoreBtn.addEventListener('click', restoreFile);
        restoreDownloadBtn.addEventListener('click', downloadRestoredFile);
        
        // 处理文件选择
        function handleFileSelect(file) {
            showStatus(`已选择文件: ${file.name} (${formatFileSize(file.size)})`, 'info');
            convertBtn.disabled = false;
            resetPreviews();
            
            // 显示文件预览
            showFilePreview(file);
        }
        
        // 处理还原文件选择
        function handleRestoreFileSelect(file) {
            showRestoreStatus(`已选择媒体文件: ${file.name} (${formatFileSize(file.size)})`, 'info');
            restoreBtn.disabled = false;
            
            // 显示文件预览
            if (file.type.startsWith('image/')) {
                restoreMediaType.value = 'image';
            } else if (file.type.startsWith('audio/')) {
                restoreMediaType.value = 'audio';
            }
        }
        
        // 显示文件预览
        function showFilePreview(file) {
            filePreviewEl.innerHTML = '';
            
            if (file.type.startsWith('image/')) {
                const img = document.createElement('img');
                img.src = URL.createObjectURL(file);
                img.style.maxWidth = '100%';
                img.style.maxHeight = '200px';
                filePreviewEl.appendChild(img);
            } else if (file.type.startsWith('audio/')) {
                const audio = document.createElement('audio');
                audio.src = URL.createObjectURL(file);
                audio.controls = true;
                audio.style.width = '100%';
                filePreviewEl.appendChild(audio);
            } else if (file.type.startsWith('video/')) {
                const video = document.createElement('video');
                video.src = URL.createObjectURL(file);
                video.controls = true;
                video.style.maxWidth = '100%';
                video.style.maxHeight = '200px';
                filePreviewEl.appendChild(video);
            } else if (file.type.startsWith('text/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const pre = document.createElement('pre');
                    pre.textContent = e.target.result.substring(0, 500); // 只显示前500个字符
                    if (e.target.result.length > 500) {
                        pre.textContent += '...';
                    }
                    pre.style.maxHeight = '200px';
                    pre.style.overflow = 'auto';
                    filePreviewEl.appendChild(pre);
                };
                reader.readAsText(file);
            } else {
                const p = document.createElement('p');
                p.textContent = `文件类型: ${file.type || '未知'}\n文件大小: ${formatFileSize(file.size)}`;
                filePreviewEl.appendChild(p);
            }
        }
        
        // 转换文件为媒体格式
        async function convertFile() {
            if (!selectedFile) {
                showStatus('请先选择文件', 'error');
                return;
            }
            
            if (!mediaConverter) {
                showStatus('WASM模块尚未加载完成，请稍后再试', 'error');
                return;
            }
            
            try {
                showLoading(true);
                showProgress(0);
                showStatus('正在转换文件...', 'info');
                
                // 读取文件为base64
                const fileDataBase64 = await readFileAsBase64(selectedFile);
                
                // 发送请求到后端获取原始数据
                const response = await fetch('/api/convert', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        file_data: fileDataBase64,
                        target_format: targetFormat.value,
                        image_format: targetFormat.value === 'image' ? imageFormat.value : null
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    // 使用WASM处理数据
                    showStatus('正在使用WASM处理数据...', 'info');
                    let mediaDataUrl = '';
                    let mediaType = '';
                    
                    const fileBytes = Uint8Array.from(atob(result.file_data), c => c.charCodeAt(0));
                    
                    if (result.target_format === 'image') {
                        const format = result.image_format || 'png';
                        mediaDataUrl = MediaConverter.file_bytes_to_image_data_url(fileBytes, format);
                        mediaType = `image/${format}`;
                    } else if (result.target_format === 'audio') {
                        mediaDataUrl = MediaConverter.file_bytes_to_audio_data_url(fileBytes);
                        mediaType = 'audio/wav';
                    } else {
                        throw new Error('不支持的格式');
                    }
                    
                    // 提取base64数据
                    convertedMediaData = mediaDataUrl.split(',')[1];
                    convertedMediaType = mediaType;
                    
                    // 显示预览
                    if (result.target_format === 'image') {
                        imagePreview.src = mediaDataUrl;
                        imagePreview.style.display = 'block';
                        audioPlayer.style.display = 'none';
                        videoPlayer.style.display = 'none';
                    } else if (result.target_format === 'audio') {
                        audioPlayer.src = mediaDataUrl;
                        audioPlayer.style.display = 'block';
                        imagePreview.style.display = 'none';
                        videoPlayer.style.display = 'none';
                    } else {
                        // 视频处理
                        videoPlayer.src = mediaDataUrl;
                        videoPlayer.style.display = 'block';
                        imagePreview.style.display = 'none';
                        audioPlayer.style.display = 'none';
                    }
                    
                    downloadSection.style.display = 'block';
                    showStatus('文件转换完成', 'success');
                    showProgress(100);
                } else {
                    throw new Error(result.message || '转换失败');
                }
            } catch (error) {
                console.error('转换失败:', error);
                showStatus('文件转换失败: ' + error.message, 'error');
            } finally {
                showLoading(false);
            }
        }
        
        // 从媒体还原文件
        async function restoreFile() {
            if (!restoreSelectedFile) {
                showRestoreStatus('请先选择媒体文件', 'error');
                return;
            }
            
            if (!mediaConverter) {
                showRestoreStatus('WASM模块尚未加载完成，请稍后再试', 'error');
                return;
            }
            
            try {
                showRestoreLoading(true);
                showRestoreProgress(0);
                showRestoreStatus('正在还原文件...', 'info');
                
                // 读取文件为base64
                const fileDataBase64 = await readFileAsBase64(restoreSelectedFile);
                
                // 使用WASM还原数据
                let fileBytes = new Uint8Array();
                if (restoreMediaType.value === 'image') {
                    const dataUrl = `data:image/png;base64,${fileDataBase64}`;
                    fileBytes = MediaConverter.image_data_url_to_file_bytes(dataUrl);
                } else if (restoreMediaType.value === 'audio') {
                    const dataUrl = `data:audio/wav;base64,${fileDataBase64}`;
                    fileBytes = MediaConverter.audio_data_url_to_file_bytes(dataUrl);
                } else {
                    throw new Error('不支持的媒体类型');
                }
                
                // 检查还原是否成功
                if (fileBytes.length === 0) {
                    throw new Error('文件还原失败，请确保选择了有效的媒体文件');
                }
                
                // 保存还原的文件数据
                restoredFileData = fileBytes;
                
                restoreDownloadSection.style.display = 'block';
                showRestoreStatus('文件还原完成', 'success');
                showRestoreProgress(100);
            } catch (error) {
                console.error('还原失败:', error);
                showRestoreStatus('文件还原失败: ' + error.message, 'error');
            } finally {
                showRestoreLoading(false);
            }
        }
        
        // 下载转换后的媒体
        function downloadConvertedMedia() {
            if (!convertedMediaData) {
                showStatus('没有可下载的媒体数据', 'error');
                return;
            }
            
            const a = document.createElement('a');
            if (targetFormat.value === 'image') {
                a.href = 'data:image/' + imageFormat.value + ';base64,' + convertedMediaData;
                a.download = 'converted_file.' + imageFormat.value;
            } else if (targetFormat.value === 'audio') {
                a.href = 'data:audio/wav;base64,' + convertedMediaData;
                a.download = 'converted_file.wav';
            } else {
                a.href = 'data:video/mp4;base64,' + convertedMediaData;
                a.download = 'converted_file.mp4';
            }
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            
            showStatus('媒体文件已下载', 'success');
        }
        
        // 下载还原的文件
        function downloadRestoredFile() {
            if (!restoredFileData) {
                showRestoreStatus('没有可下载的文件数据', 'error');
                return;
            }
            
            // 将Uint8Array转换为Blob
            const blob = new Blob([restoredFileData], {type: 'application/octet-stream'});
            const url = URL.createObjectURL(blob);
            
            // 创建临时下载链接
            const a = document.createElement('a');
            a.href = url;
            a.download = 'restored_file.dat';
            document.body.appendChild(a);
            a.click();
            
            // 清理
            setTimeout(() => {
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            }, 100);
            
            showRestoreStatus('还原文件已下载', 'success');
        }
        
        // 工具函数：读取文件为base64
        function readFileAsBase64(file) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => {
                    // 移除数据URL前缀
                    const base64 = reader.result.split(',')[1];
                    resolve(base64);
                };
                reader.onerror = () => reject(reader.error);
                reader.readAsDataURL(file);
            });
        }
        
        // 工具函数：格式化文件大小
        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }
        
        // 工具函数：获取文件扩展名
        function getFileExtension(filename) {
            return filename.substring(filename.lastIndexOf('.'));
        }
        
        // 显示状态信息
        function showStatus(message, type) {
            statusEl.textContent = message;
            statusEl.className = 'status ' + type;
        }
        
        // 显示还原状态信息
        function showRestoreStatus(message, type) {
            restoreStatusEl.textContent = message;
            restoreStatusEl.className = 'status ' + type;
        }
        
        // 显示/隐藏加载状态
        function showLoading(show) {
            loadingEl.style.display = show ? 'block' : 'none';
        }
        
        // 显示/隐藏还原加载状态
        function showRestoreLoading(show) {
            restoreLoadingEl.style.display = show ? 'block' : 'none';
        }
        
        // 显示进度
        function showProgress(percent) {
            progressContainer.style.display = 'block';
            progressBar.style.width = percent + '%';
            
            if (percent >= 100) {
                setTimeout(() => {
                    progressContainer.style.display = 'none';
                }, 1000);
            }
        }
        
        // 显示还原进度
        function showRestoreProgress(percent) {
            restoreProgressContainer.style.display = 'block';
            restoreProgressBar.style.width = percent + '%';
            
            if (percent >= 100) {
                setTimeout(() => {
                    restoreProgressContainer.style.display = 'none';
                }, 1000);
            }
        }
        
        // 重置预览
        function resetPreviews() {
            imagePreview.style.display = 'none';
            audioPlayer.style.display = 'none';
            videoPlayer.style.display = 'none';
            downloadSection.style.display = 'none';
            convertedMediaData = null;
        }
    </script>
</body>
</html>"#;

#[tokio::main]
async fn main() {
    // 主页路由 - 提供内联HTML
    let index = warp::path::end()
        .and(warp::get())
        .map(|| warp::reply::html(INDEX_HTML));
    
    // API路由 - 文件到媒体转换
    let convert_api = warp::path("api")
        .and(warp::path("convert"))
        .and(warp::post())
        .and(warp::body::json())
        .map(|req: ConvertRequest| {
            // 验证base64文件数据
            if general_purpose::STANDARD.decode(&req.file_data).is_err() {
                let response = ConvertResponse {
                    success: false,
                    message: "Invalid base64 data".to_string(),
                    file_data: String::new(),
                    target_format: String::new(),
                    image_format: None,
                };
                return warp::reply::json(&response);
            }
            
            // 返回原始数据供前端WASM处理
            let response = ConvertResponse {
                success: true,
                message: "File data ready for frontend processing".to_string(),
                file_data: req.file_data,
                target_format: req.target_format,
                image_format: req.image_format,
            };
            
            warp::reply::json(&response)
        });
    
    // API路由 - 媒体到文件还原
    let reverse_convert_api = warp::path("api")
        .and(warp::path("reverse-convert"))
        .and(warp::post())
        .and(warp::body::json())
        .map(|req: ReverseConvertRequest| {
            // 验证base64媒体数据
            if general_purpose::STANDARD.decode(&req.media_data).is_err() {
                let response = ReverseConvertResponse {
                    success: false,
                    file_data: String::new(),
                    message: "Invalid base64 data".to_string(),
                };
                return warp::reply::json(&response);
            }
            
            // 返回原始数据供前端WASM处理
            let response = ReverseConvertResponse {
                success: true,
                file_data: req.media_data,
                message: "Media data ready for frontend processing".to_string(),
            };
            
            warp::reply::json(&response)
        });
    
    // 提供WASM文件，确保正确的MIME类型
    let wasm_files = warp::path("pkg")
        .and(warp::fs::dir("pkg"))
        .map(|reply: warp::filters::fs::File| {
            let path = reply.path().to_str().unwrap_or("");
            let mime_type = if path.ends_with(".js") {
                "application/javascript"
            } else if path.ends_with(".wasm") {
                "application/wasm"
            } else {
                "application/octet-stream"
            };
            
            warp::reply::with_header(reply, "content-type", mime_type)
        });
    
    // 提供静态文件（CSS等）
    let static_files = warp::path("static")
        .and(warp::fs::dir("static"));
    
    // 组合所有路由
    let routes = index
        .or(convert_api)
        .or(reverse_convert_api)
        .or(wasm_files)
        .or(static_files);
    
    println!("VisiWASM Server starting on http://localhost:9920");
    
    // 启动服务器
    warp::serve(routes)
        .run(([0, 0, 0, 0], 9920))
        .await;
}
