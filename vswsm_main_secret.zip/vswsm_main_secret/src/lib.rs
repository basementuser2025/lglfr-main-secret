use wasm_bindgen::prelude::*;
use image::{ImageBuffer, Rgba, ImageEncoder}; // 添加ImageEncoder trait
use base64::{Engine as _, engine::general_purpose};
use std::io::Cursor;

#[wasm_bindgen]
extern "C" {
    #[wasm_bindgen(js_namespace = console)]
    fn log(s: &str);
}

#[wasm_bindgen]
pub struct MediaConverter;

#[wasm_bindgen]
impl MediaConverter {
    #[wasm_bindgen(constructor)]
    pub fn new() -> MediaConverter {
        MediaConverter
    }

    /// 将文件字节数据转换为PNG图像数据URL
    #[wasm_bindgen]
    pub fn file_bytes_to_image_data_url(file_bytes: &[u8]) -> String {
        // 计算图像尺寸
        let data_len = file_bytes.len();
        
        // 添加元数据：前4个字节存储原始文件大小
        let metadata_size = 4;
        let total_data_len = data_len + metadata_size;
        
        // 每个像素可以存储4字节（RGBA）
        let pixels_needed = (total_data_len + 3) / 4;
        let sqrt_pixels = (pixels_needed as f64).sqrt().ceil() as u32;
        
        // 创建正方形图像
        let width = sqrt_pixels;
        let height = sqrt_pixels;
        
        // 创建图像缓冲区
        let mut img_buffer: ImageBuffer<Rgba<u8>, Vec<u8>> = ImageBuffer::new(width, height);
        
        // 将元数据（文件大小）写入图像的前4个字节
        let mut byte_index = 0;
        let data_size_bytes = (data_len as u32).to_le_bytes();
        
        // 写入元数据
        for pixel in img_buffer.pixels_mut().take(1) {
            for channel in 0..4 {
                if byte_index < metadata_size {
                    pixel[channel] = data_size_bytes[byte_index];
                    byte_index += 1;
                } else {
                    pixel[channel] = 0;
                }
            }
        }
        
        // 写入文件数据
        byte_index = 0;
        for (i, pixel) in img_buffer.pixels_mut().enumerate() {
            // 跳过第一个像素（元数据）
            if i == 0 { continue; }
            
            // 每个像素存储4字节数据
            for channel in 0..4 {
                if byte_index < data_len {
                    pixel[channel] = file_bytes[byte_index];
                    byte_index += 1;
                } else {
                    // 用0填充剩余空间
                    pixel[channel] = 0;
                }
            }
        }
        
        // 将图像编码为PNG
        let mut png_data: Vec<u8> = Vec::new();
        {
            let encoder = image::codecs::png::PngEncoder::new(&mut png_data);
            encoder.write_image(&img_buffer, width, height, image::ColorType::Rgba8)
                .expect("Failed to encode image");
        }
        
        // 将PNG数据转换为base64数据URL
        let base64_data = general_purpose::STANDARD.encode(&png_data);
        format!("data:image/png;base64,{}", base64_data)
    }
    
    /// 从图像数据URL提取文件字节数据
    #[wasm_bindgen]
    pub fn image_data_url_to_file_bytes(data_url: &str) -> Vec<u8> {
        // 移除数据URL前缀
        let base64_data = data_url.split(',').nth(1).unwrap_or("");
        
        // 解码base64数据
        let png_data = general_purpose::STANDARD
            .decode(base64_data)
            .expect("Failed to decode base64 data");
        
        // 解码PNG图像
        let img = image::load_from_memory(&png_data)
            .expect("Failed to load image from PNG data");
        
        let rgba_img = img.to_rgba8();
        let pixels = rgba_img.pixels().collect::<Vec<_>>();
        
        // 从第一个像素读取元数据（原始文件大小）
        let metadata_pixel = pixels[0];
        let file_size = u32::from_le_bytes([
            metadata_pixel[0], 
            metadata_pixel[1], 
            metadata_pixel[2], 
            metadata_pixel[3]
        ]) as usize;
        
        // 从图像中提取文件数据
        let mut file_bytes: Vec<u8> = Vec::with_capacity(file_size);
        
        // 从第二个像素开始读取文件数据
        for (i, pixel) in pixels.iter().enumerate() {
            // 跳过第一个像素（元数据）
            if i == 0 { continue; }
            
            // 从每个像素的RGBA通道中提取数据
            for channel in 0..4 {
                let data_index = (i - 1) * 4 + channel;
                if data_index < file_size {
                    file_bytes.push(pixel[channel]);
                } else {
                    break;
                }
            }
        }
        
        file_bytes
    }
    
    /// 将文件字节数据转换为WAV音频数据URL
    #[wasm_bindgen]
    pub fn file_bytes_to_audio_data_url(file_bytes: &[u8]) -> String {
        // 添加元数据：前4个字节存储原始文件大小
        let data_len = file_bytes.len();
        let metadata_size = 4;
        let total_data_len = data_len + metadata_size;
        
        // 创建WAV样本数据（16位）
        let mut samples: Vec<i16> = Vec::with_capacity(total_data_len);
        
        // 写入元数据（文件大小）
        let data_size_bytes = (data_len as u32).to_le_bytes();
        for i in 0..metadata_size {
            samples.push(data_size_bytes[i] as i16);
        }
        
        // 写入文件数据
        for &byte in file_bytes {
            samples.push(byte as i16);
        }
        
        // 创建WAV数据
        let mut wav_data = Vec::new();
        let spec = hound::WavSpec {
            channels: 1,
            sample_rate: 44100,
            bits_per_sample: 16,
            sample_format: hound::SampleFormat::Int,
        };
        
        {
            let cursor = Cursor::new(&mut wav_data);
            let mut writer = hound::WavWriter::new(cursor, spec).expect("Failed to create WAV writer");
            for sample in samples {
                writer.write_sample(sample).expect("Failed to write sample");
            }
            writer.finalize().expect("Failed to finalize WAV");
        }
        
        // 将WAV数据转换为base64数据URL
        let base64_data = general_purpose::STANDARD.encode(&wav_data);
        format!("data:audio/wav;base64,{}", base64_data)
    }
    
    /// 从音频数据URL提取文件字节数据
    #[wasm_bindgen]
    pub fn audio_data_url_to_file_bytes(data_url: &str) -> Vec<u8> {
        // 移除数据URL前缀
        let base64_data = data_url.split(',').nth(1).unwrap_or("");
        
        // 解码base64数据
        let wav_data = general_purpose::STANDARD
            .decode(base64_data)
            .expect("Failed to decode base64 data");
        
        // 解码WAV音频
        let cursor = Cursor::new(&wav_data);
        let mut reader = hound::WavReader::new(cursor)
            .expect("Failed to load audio from WAV data");
        
        let samples: Vec<i16> = reader.samples()
            .map(|s| s.expect("Failed to read sample"))
            .collect();
        
        // 从样本中读取元数据（原始文件大小）
        let file_size = u32::from_le_bytes([
            samples[0] as u8, 
            samples[1] as u8, 
            samples[2] as u8, 
            samples[3] as u8
        ]) as usize;
        
        // 从样本中提取文件数据
        let mut file_bytes: Vec<u8> = Vec::with_capacity(file_size);
        
        // 从第五个样本开始读取文件数据
        for i in 4..samples.len() {
            if (i - 4) < file_size {
                file_bytes.push(samples[i] as u8);
            } else {
                break;
            }
        }
        
        file_bytes
    }
}