/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_mediaconverter_free: (a: number, b: number) => void;
export const mediaconverter_new: () => number;
export const mediaconverter_file_bytes_to_image_data_url: (a: number, b: number, c: number, d: number) => [number, number];
export const mediaconverter_image_data_url_to_file_bytes: (a: number, b: number) => [number, number];
export const mediaconverter_file_bytes_to_audio_data_url: (a: number, b: number) => [number, number];
export const mediaconverter_audio_data_url_to_file_bytes: (a: number, b: number) => [number, number];
export const __wbindgen_export_0: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
